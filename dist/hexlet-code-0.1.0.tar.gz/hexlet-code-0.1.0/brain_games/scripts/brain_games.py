#!/usr/bin/env python

def greet(who):
    print(f'Welcome to the {who}!')

def main():
    greet('Brain games')


if __name__== '__main__':
    main()
    
