"""Brain-games package."""
